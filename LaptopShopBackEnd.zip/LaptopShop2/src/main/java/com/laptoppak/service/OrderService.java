package com.laptoppak.service;

import java.util.List;

import com.laptoppak.model.Order;
import com.laptoppak.model.User;


public interface OrderService {
	
	public Order saveOrder(Order order);
	public List<Order> getAllOrders();
	public Order getOrderById(int orderId);
	public void removeOrder(int orderId);
	Order updateOrder(Order order, int orderId);
	
	public Order findByUserId(long userId);

}
