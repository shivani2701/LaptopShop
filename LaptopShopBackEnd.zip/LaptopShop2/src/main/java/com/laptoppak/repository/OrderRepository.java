package com.laptoppak.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.laptoppak.model.Order;
import com.laptoppak.model.User;



public interface OrderRepository extends JpaRepository<Order,Integer>{
	
	public List<Order> findByUserId(long userId);

}
