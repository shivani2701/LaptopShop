package com.laptoppak.service;

import com.laptoppak.model.BankServer;

public interface BankServerService {
	 
public BankServer saveDetails(BankServer bankServer);

public BankServer findByCardCvv(Long cardNumber, Integer cvvNumber, String expiryDate , String cardHolderName);

}