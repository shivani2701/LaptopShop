package com.laptoppak.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.laptoppak.model.BankServer;
import com.laptoppak.repository.BankServerRepository;
import com.laptoppak.service.BankServerService;

@Service
public class BankServerImpl implements BankServerService {

	@Autowired
	private BankServerRepository bankServerRepository;
	
	@Override
	public BankServer saveDetails(BankServer bankServer) {
		
		return bankServerRepository.save(bankServer);
	}
	@Override
	public BankServer findByCardCvv(Long cardNumber, Integer cvvNumber,String expiryDate,String cardHolderName) {
		return bankServerRepository.findByCardCvv(cardNumber,cvvNumber,expiryDate,cardHolderName);
	}
	
}